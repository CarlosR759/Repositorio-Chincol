buscarBomberosPorRut(char *rut){



    return;
}