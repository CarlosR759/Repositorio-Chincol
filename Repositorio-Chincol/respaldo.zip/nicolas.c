#include <stdio.h>

int main(void){
    printf("nicolas testing.-");
    printf("\nhola, espero que funciones :)");
    return 0;
}