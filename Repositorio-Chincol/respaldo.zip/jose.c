#include <stdio.h>

int main(void){
    //Tienen que imrpimir algo por acá para saber que les funciona editar//
  printf("alooooo");
    return 0;
}