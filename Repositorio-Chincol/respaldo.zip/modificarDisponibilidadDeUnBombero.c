modificarDisponibilidadDeUnBombero(char *rut, int disponibilidad[] ){




    return;
}