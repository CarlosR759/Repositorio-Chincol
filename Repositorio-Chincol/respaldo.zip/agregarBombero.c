agregarBombero(char *rut, char *nombre, int disponibilidad[] ){



    return;
}