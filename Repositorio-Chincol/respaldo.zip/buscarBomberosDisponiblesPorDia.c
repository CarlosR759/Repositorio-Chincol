buscarBomberosDisponiblesPorDia(char *dia){



    return;
}