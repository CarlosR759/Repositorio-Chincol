#include <stdio.h>

int main(void){
    //Tienen que imprimir lo que quieran acá para saber que pueden editar//
    printf("Hola mundo");
    printf("Acabo de ver lo que hicieron y les quedó super!");

    return 0;
}
