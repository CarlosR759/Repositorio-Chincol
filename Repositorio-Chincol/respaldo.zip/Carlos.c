#include <stdio.h>

int main(void){
    printf("Hola :D \n");
    int suma = 1 + 1;
    printf("\n%d", suma);
   return 0; 
}