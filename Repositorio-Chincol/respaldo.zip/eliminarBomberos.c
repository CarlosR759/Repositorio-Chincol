eliminarBomberos(char *rut){


    return;
}